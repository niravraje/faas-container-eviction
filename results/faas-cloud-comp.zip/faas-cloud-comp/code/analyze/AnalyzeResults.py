#!/usr/bin/python3
import argparse
import multiprocessing as mp
import pickle
import os

import matplotlib as mpl
mpl.rcParams.update({'font.size': 14})
mpl.use('Agg')

def analyze_timings(policy, lambdas, msd):
    """ Effective access time, etc. """
    total_cold = []
    avg_latencies = []
    pct_increases = []
    out_dict = dict()  # BAD: We'll insert some global and some per-key stats
    out_dict["global"] = dict()
    out_dict["global"]["server_cold"] = 0
    total_accesses = 0  # for computing weighted averages

    for k in sorted(msd.keys()):
        out_dict[k] = dict()
        misses = msd[k]['misses']
        hits = msd[k]['hits']

        out_dict[k]["misses"] = misses
        out_dict[k]["hits"] = hits
        out_dict[k]["accesses"] = misses+hits
        total_accesses += out_dict[k]["accesses"]

        twarm = lambdas[k][3]
        trun = lambdas[k][2]

        out_dict[k]["total_cold"] = misses
        out_dict["global"]["server_cold"] += out_dict[k]["total_cold"]
        #Effective acccess time
        out_dict[k]["eat"] = (
            (misses*trun) + (hits*(trun-twarm)))/(misses+hits)

        if trun-twarm == 0:
            pct_incr = 0
        else:
            pct_incr = twarm*misses/((misses+hits)*(trun-twarm))
        out_dict[k]["pct_incr_vs_all_hits"] = pct_incr
    #
    out_dict["global"]["server_cold"] = out_dict["global"]["server_cold"]/total_accesses

    out_dict["global"]["wted_eat"] = sum([out_dict[k]["eat"]*out_dict[k]["accesses"]/total_accesses
                                          for k in msd.keys()])

    out_dict["global"]["wted_increase"] = sum([out_dict[k]["pct_incr_vs_all_hits"]*out_dict[k]["accesses"]/total_accesses
                                               for k in msd.keys()])

    return out_dict


def get_info_from_file(filename):
    policy, num_funcs, mem, run = filename[:-5].split("-")
    return policy, int(num_funcs), int(float(mem)), run


def load_data(path):
    with open(path, "r+b") as f:
        return pickle.load(f)


def compute_timings(file):
    pth = os.path.join(data_path, file)
    policy, num_funcs, mem, run = get_info_from_file(file)
    policy, evdict, miss_stats, lambdas, capacity_misses, len_trace = load_data(pth)
    anal = analyze_timings(policy, lambdas, miss_stats)

    total_misses = sum(capacity_misses.values())

    name = "{}-{}-{}-{}.pckl".format(policy, num_funcs, mem, run)
    # capacity_misses: dict[func_name] = invocations_not_handled
    # len_trace: long
    data = (policy, anal, capacity_misses, len_trace)
   
    cold_pct = anal["global"]["server_cold"]
    dropped_pct = (total_misses / len_trace) * 100
    print(name, "Cold starts %:", cold_pct*100, "; Dropped %:", dropped_pct)


def compute_all(data_path):
    with mp.Pool() as pool:
        files = [file for file in os.listdir(
            data_path) if os.path.isfile(os.path.join(data_path, file))]
        print("computing {} files".format(len(files)))
        pool.map(compute_timings, files)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='analyze FaasCache Simulation')
    parser.add_argument("--pckldir", type=str,
                        default="/data/alfuerst/verify-test/", required=False)
    args = parser.parse_args()
    data_path = args.pckldir
    compute_all(args.pckldir)
